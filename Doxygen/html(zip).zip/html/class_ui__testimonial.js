var class_ui__testimonial =
[
    [ "retranslateUi", "class_ui__testimonial.html#a339cda900b672fb9e5ca785b4c3330eb", null ],
    [ "setupUi", "class_ui__testimonial.html#ad08d5ac2c79d0870fd6b23cc6d6afa96", null ],
    [ "button_Save", "class_ui__testimonial.html#a91c769777b8bcef047507ece86e95115", null ],
    [ "label_name1", "class_ui__testimonial.html#ad11211bd97c3aae08eda6563ead1b626", null ],
    [ "label_name2", "class_ui__testimonial.html#a28a0b205d941d13bb087c28fa6fc7196", null ],
    [ "label_name3", "class_ui__testimonial.html#a4f8af6723538155d05c3075cad8d59cc", null ],
    [ "label_test1", "class_ui__testimonial.html#ac1dca0bca97ed7a16f30ef1bf7aeec1e", null ],
    [ "label_test2", "class_ui__testimonial.html#a4fa1db1c1431c4b38567cc5c3148f036", null ],
    [ "label_test3", "class_ui__testimonial.html#aefb91757183b12d8e52db1ae47fafd89", null ],
    [ "label_testTitle", "class_ui__testimonial.html#ad5ece9a1764acf1829afde09fb4d6cb2", null ],
    [ "label_title", "class_ui__testimonial.html#ac9c1ec8d4a9afbc36b8ec7f8981ca4b9", null ],
    [ "textEdit", "class_ui__testimonial.html#afd3ba9fb052486d36efcb93f6b0faa6a", null ]
];