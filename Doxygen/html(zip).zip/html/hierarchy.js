var hierarchy =
[
    [ "Cmp_by_area", "struct_cmp__by__area.html", null ],
    [ "Cmp_by_id", "struct_cmp__by__id.html", null ],
    [ "Cmp_by_perimeter", "struct_cmp__by__perimeter.html", null ],
    [ "QDialog", null, [
      [ "ContactUs", "class_contact_us.html", null ],
      [ "LoginDialog", "class_login_dialog.html", null ],
      [ "MoveShape", "class_move_shape.html", null ],
      [ "testimonial", "classtestimonial.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "RenderArea", "class_render_area.html", null ]
    ] ],
    [ "Shape", "class_shape.html", [
      [ "Ellipse", "class_ellipse.html", null ],
      [ "Line", "class_line.html", null ],
      [ "Polygon", "class_polygon.html", null ],
      [ "Polyline", "class_polyline.html", null ],
      [ "Rectangle", "class_rectangle.html", null ],
      [ "Text", "class_text.html", null ]
    ] ],
    [ "TextParser", "class_text_parser.html", null ],
    [ "Ui_ContactUs", "class_ui___contact_us.html", [
      [ "Ui::ContactUs", "class_ui_1_1_contact_us.html", null ]
    ] ],
    [ "Ui_LoginDialog", "class_ui___login_dialog.html", [
      [ "Ui::LoginDialog", "class_ui_1_1_login_dialog.html", null ]
    ] ],
    [ "Ui_MainWindow", "class_ui___main_window.html", [
      [ "Ui::MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Ui_MoveShape", "class_ui___move_shape.html", [
      [ "Ui::MoveShape", "class_ui_1_1_move_shape.html", null ]
    ] ],
    [ "Ui_testimonial", "class_ui__testimonial.html", [
      [ "Ui::testimonial", "class_ui_1_1testimonial.html", null ]
    ] ],
    [ "vector< T >", "classvector.html", null ],
    [ "vector< Shape * >", "classvector.html", null ]
];