var class_text =
[
    [ "Text", "class_text.html#ad6edd4d20290cf4b9d711ad16df8f2a1", null ],
    [ "Text", "class_text.html#a9f44ea4234a9a7e9b9e822b27630bf6b", null ],
    [ "CalcArea", "class_text.html#aee816994645c1b04c1063605d9c7cde5", null ],
    [ "CalcPerimeter", "class_text.html#a97ead8733ef6ef96093a5023d5f9d0e1", null ],
    [ "Draw", "class_text.html#a26ea27ecc1bb94a4cf83dcfc09a8b824", null ],
    [ "GetAlign", "class_text.html#a7f1edf51b33a01491115d1b648dcf88b", null ],
    [ "GetFont", "class_text.html#a2e02ee3c918e47ef930e5e7bccc5ce41", null ],
    [ "GetTextString", "class_text.html#a7846a8a691df2609f5b4e4e56832713b", null ],
    [ "SetAlignment", "class_text.html#aabe8e434f78b3dba81295e1f47ced89e", null ],
    [ "SetColor", "class_text.html#ad5c379a11ea165b2ecc5e75d8ad7b0dd", null ],
    [ "SetFont", "class_text.html#a8958583a4260eba0ebb92bca491b3d0c", null ],
    [ "SetHeight", "class_text.html#ac5136b2e8186acb3e8752bf8a19814cf", null ],
    [ "SetTextString", "class_text.html#adf13807a793b34154fb810fb6d760965", null ],
    [ "SetWidth", "class_text.html#a6bb2b416f73e2b5ce5a7ce8d65492b3a", null ]
];