var class_move_shape =
[
    [ "MoveShape", "class_move_shape.html#ad3bb05119f77845e54fa08cd97fb04cc", null ],
    [ "~MoveShape", "class_move_shape.html#a9790764b1e1ec53da191338e6fa763ac", null ],
    [ "setVector", "class_move_shape.html#a8e6c32c24312a98d18056d50d52626e1", null ],
    [ "anID", "class_move_shape.html#aa864da19c90b418eb3414a7c073900d3", null ],
    [ "x", "class_move_shape.html#a0ca24fbd5421c01eaf835ce996fdb506", null ],
    [ "y", "class_move_shape.html#a193e4a984e6808047312de6905932584", null ]
];