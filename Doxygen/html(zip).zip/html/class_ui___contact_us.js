var class_ui___contact_us =
[
    [ "retranslateUi", "class_ui___contact_us.html#a450b14784e49048a12740d6ba6dd0ba8", null ],
    [ "setupUi", "class_ui___contact_us.html#abe9c8db1809059fa8aab6db9c1e466b2", null ],
    [ "groupBox", "class_ui___contact_us.html#add35cf2c75b5d0804df9cfd672004d9f", null ],
    [ "label_email", "class_ui___contact_us.html#a6a2dc492af0e1f0d1b65d0de3f98e624", null ],
    [ "label_logo", "class_ui___contact_us.html#a1d73d6d90432013abb10d75e3e4f92db", null ],
    [ "lebel_title", "class_ui___contact_us.html#abd222d6c997408599018b90cb8788b61", null ],
    [ "pushButton", "class_ui___contact_us.html#a80dbfdc0f6062a8507a87956f80cda96", null ]
];