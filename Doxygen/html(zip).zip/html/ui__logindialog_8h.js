var ui__logindialog_8h =
[
    [ "Ui_LoginDialog", "class_ui___login_dialog.html", "class_ui___login_dialog" ],
    [ "Ui::LoginDialog", "class_ui_1_1_login_dialog.html", null ]
];