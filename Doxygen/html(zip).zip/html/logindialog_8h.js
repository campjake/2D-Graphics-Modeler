var logindialog_8h =
[
    [ "LoginDialog", "class_login_dialog.html", "class_login_dialog" ]
];