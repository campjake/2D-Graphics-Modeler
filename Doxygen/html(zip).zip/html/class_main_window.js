var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "setCredentials", "class_main_window.html#a44edbabe209375f07ade0a4f24b54889", null ],
    [ "LoginDialog", "class_main_window.html#aa036070366b404d4bc767bdc56fc958e", null ]
];