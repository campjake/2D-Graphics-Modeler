var class_login_dialog =
[
    [ "LoginDialog", "class_login_dialog.html#a7456f32deb63b8d3fb66b76f1e97977e", null ],
    [ "~LoginDialog", "class_login_dialog.html#aa5d012ebc424713ca0cbd82be1f81133", null ],
    [ "adminCredentials", "class_login_dialog.html#a617160e0b8f35614e2c2fbe10ee7cec7", null ],
    [ "getMatch", "class_login_dialog.html#a8847b9b422116f94893030ac43cbe6f2", null ],
    [ "setAdmin", "class_login_dialog.html#aac7b6861f18da5213967fca6fe8576a5", null ],
    [ "MainWindow", "class_login_dialog.html#af9db4b672c4d3104f5541893e08e1809", null ]
];