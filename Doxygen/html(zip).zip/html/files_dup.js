var files_dup =
[
    [ "QT_2DGraphicsModeler", "dir_fbaea35b3ef853d729c379b0c8c43165.html", "dir_fbaea35b3ef853d729c379b0c8c43165" ]
];