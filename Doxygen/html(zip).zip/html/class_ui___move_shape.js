var class_ui___move_shape =
[
    [ "retranslateUi", "class_ui___move_shape.html#a84e7b282ebaf5a70af3a64f4363f5a8c", null ],
    [ "setupUi", "class_ui___move_shape.html#a3423dba6a7e24177f6a823a4cda37105", null ],
    [ "buttonBox", "class_ui___move_shape.html#a0f6c594ed07303511067f38abcf1e668", null ],
    [ "label", "class_ui___move_shape.html#a8fcfa9b75c7fb7629042b97776b34d29", null ],
    [ "label_2", "class_ui___move_shape.html#a603fd856694a2cca866570622bf1b0de", null ],
    [ "label_3", "class_ui___move_shape.html#a64490bd79879f81ddde0aa8e088f105f", null ],
    [ "spinBox", "class_ui___move_shape.html#a6ed55b69dd190e3fd8ce8e904cab33af", null ],
    [ "splitter", "class_ui___move_shape.html#a5811f08f91492a68e047314dc3125163", null ],
    [ "splitter_2", "class_ui___move_shape.html#a3ac4f4f55b285f301be0b40fc669ef63", null ],
    [ "splitter_3", "class_ui___move_shape.html#a4788e159aeab55af528de4e1a6a481a9", null ],
    [ "splitter_4", "class_ui___move_shape.html#a6ae644e9bac4836a8f54f477a783d897", null ],
    [ "splitter_5", "class_ui___move_shape.html#a98dc18688502a294c51da3d589a84dfc", null ],
    [ "xLine", "class_ui___move_shape.html#aa2b37a7f2d337e7bfc0de90466fe035d", null ],
    [ "yLine", "class_ui___move_shape.html#ae5eceb19fdd168759abc75aa9b9af2fe", null ]
];