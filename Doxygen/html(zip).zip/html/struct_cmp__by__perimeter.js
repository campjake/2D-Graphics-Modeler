var struct_cmp__by__perimeter =
[
    [ "operator()", "struct_cmp__by__perimeter.html#ae5596d3d1de85d01c42ce1bfd02e5d12", null ]
];