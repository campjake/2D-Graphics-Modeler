var searchData=
[
  ['testimonial_0',['testimonial',['../classtestimonial.html',1,'testimonial'],['../classtestimonial.html#adf0404b1078a1677ebfd43c7da6efa44',1,'testimonial::testimonial()'],['../class_ui_1_1testimonial.html',1,'Ui::testimonial']]],
  ['testimonial_2ecpp_1',['testimonial.cpp',['../testimonial_8cpp.html',1,'']]],
  ['testimonial_2eh_2',['testimonial.h',['../testimonial_8h.html',1,'']]],
  ['text_3',['Text',['../class_text.html',1,'Text'],['../class_text.html#ad6edd4d20290cf4b9d711ad16df8f2a1',1,'Text::Text(QPaintDevice *device=nullptr, int newID=-1, ShapeType newShapeType=ShapeType::Text)'],['../class_text.html#a9f44ea4234a9a7e9b9e822b27630bf6b',1,'Text::Text(int newId, QString newString, QFont newFont, QColor newColor, QPoint newPos, int newHeight, int newWidth, Qt::AlignmentFlag newAlign)']]],
  ['text_4',['TEXT',['../textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a9a4a47c1606e295076055a9cc4373197',1,'textparser.h']]],
  ['text_5',['Text',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a9dffbf69ffba8bc38bc4e01abf4b1675',1,'shape.h']]],
  ['text_2ecpp_6',['text.cpp',['../text_8cpp.html',1,'']]],
  ['text_2eh_7',['text.h',['../text_8h.html',1,'']]],
  ['textedit_8',['textEdit',['../class_ui__testimonial.html#afd3ba9fb052486d36efcb93f6b0faa6a',1,'Ui_testimonial']]],
  ['textparser_9',['TextParser',['../class_text_parser.html',1,'TextParser'],['../class_text_parser.html#a4438162fe3717258692da1bad6531872',1,'TextParser::TextParser()']]],
  ['textparser_2ecpp_10',['textparser.cpp',['../textparser_8cpp.html',1,'']]],
  ['textparser_2eh_11',['textparser.h',['../textparser_8h.html',1,'']]],
  ['textsizebox_12',['textSizeBox',['../class_ui___main_window.html#ae0cc5cf26b0b9893dbe7ca0dc063b24e',1,'Ui_MainWindow']]]
];
