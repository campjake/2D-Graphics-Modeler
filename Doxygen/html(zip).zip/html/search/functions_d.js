var searchData=
[
  ['testimonial_0',['testimonial',['../classtestimonial.html#adf0404b1078a1677ebfd43c7da6efa44',1,'testimonial']]],
  ['text_1',['Text',['../class_text.html#ad6edd4d20290cf4b9d711ad16df8f2a1',1,'Text::Text(QPaintDevice *device=nullptr, int newID=-1, ShapeType newShapeType=ShapeType::Text)'],['../class_text.html#a9f44ea4234a9a7e9b9e822b27630bf6b',1,'Text::Text(int newId, QString newString, QFont newFont, QColor newColor, QPoint newPos, int newHeight, int newWidth, Qt::AlignmentFlag newAlign)']]],
  ['textparser_2',['TextParser',['../class_text_parser.html#a4438162fe3717258692da1bad6531872',1,'TextParser']]]
];
