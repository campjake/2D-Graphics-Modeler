var searchData=
[
  ['line_0',['Line',['../class_line.html#ad24a3be2859ceaa692c9ee03708a30ca',1,'Line::Line(QPaintDevice *device=nullptr, int anID=-1, ShapeType shapeType=ShapeType::Line)'],['../class_line.html#af74d651e2b24f85fb4fbd06c0cf7262e',1,'Line::Line(QPaintDevice *device=nullptr, int anID=-1, ShapeType shapeType=ShapeType::Line, QPen thatPen=Qt::SolidLine)'],['../class_line.html#a6b81d5b487e5c76b33b91b03b6ade125',1,'Line::Line(int anID, QPoint first, QPoint last)'],['../class_line.html#aaa72b9bc03abe8d843abea679c0985f1',1,'Line::Line(const Line &amp;source)=delete']]],
  ['logindialog_1',['LoginDialog',['../class_login_dialog.html#a7456f32deb63b8d3fb66b76f1e97977e',1,'LoginDialog']]]
];
