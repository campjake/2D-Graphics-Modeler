var searchData=
[
  ['logindialog_0',['LoginDialog',['../class_main_window.html#aa036070366b404d4bc767bdc56fc958e',1,'MainWindow']]]
];
