var searchData=
[
  ['readcircle_0',['ReadCircle',['../class_text_parser.html#ab7e3069e3c74ecdd8b59d8f87e0f5533',1,'TextParser']]],
  ['readellipse_1',['ReadEllipse',['../class_text_parser.html#a291d399cc110db526b6f8272773cfc52',1,'TextParser']]],
  ['readfile_2',['ReadFile',['../class_text_parser.html#af2a58541b9a776763fe96d9b83a3165e',1,'TextParser']]],
  ['readline_3',['ReadLine',['../class_text_parser.html#aea874be2d469e7febc98a96c626400d0',1,'TextParser']]],
  ['readpolygon_4',['ReadPolygon',['../class_text_parser.html#ac717ec0690768012d58ff77a74256074',1,'TextParser']]],
  ['readpolyline_5',['ReadPolyline',['../class_text_parser.html#ae45a1a75e09b2927fde6dbde6faaa69c',1,'TextParser']]],
  ['readrectangle_6',['ReadRectangle',['../class_text_parser.html#a3993ae5b9b23e856a1292f52725a5f04',1,'TextParser']]],
  ['readsquare_7',['ReadSquare',['../class_text_parser.html#a5b97bfb4269e57de90e66b197afb980c',1,'TextParser']]],
  ['readtext_8',['ReadText',['../class_text_parser.html#a81816f7553e978b9441f31aecf0aa718',1,'TextParser']]],
  ['rectangle_9',['Rectangle',['../class_rectangle.html#adbb5f6ec370695bd9a6eae311f337f5d',1,'Rectangle::Rectangle(QPaintDevice *device, int anID, ShapeType shapeType, int width, int length)'],['../class_rectangle.html#a0438f4c7c36110ddc854cbd739218820',1,'Rectangle::Rectangle(int anID, QPoint aPos, int l, int w)'],['../class_rectangle.html#a49806e30609ed46c24d3ce3bde641cc3',1,'Rectangle::Rectangle(const Rectangle &amp;source)=delete']]],
  ['renderarea_10',['RenderArea',['../class_render_area.html#a6fa5a406003dc132605f8bc07763e946',1,'RenderArea']]],
  ['reserve_11',['reserve',['../classvector.html#ac12244af11fb199f2d8c1279d940e94b',1,'vector']]],
  ['resize_12',['resize',['../classvector.html#abfd8f4267db5f9864af6d4d742c21a91',1,'vector']]],
  ['retranslateui_13',['retranslateUi',['../class_ui___contact_us.html#a450b14784e49048a12740d6ba6dd0ba8',1,'Ui_ContactUs::retranslateUi()'],['../class_ui___login_dialog.html#ad2d7bb901a56825e13e265a08cab0820',1,'Ui_LoginDialog::retranslateUi()'],['../class_ui___main_window.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow::retranslateUi()'],['../class_ui___move_shape.html#a84e7b282ebaf5a70af3a64f4363f5a8c',1,'Ui_MoveShape::retranslateUi()'],['../class_ui__testimonial.html#a339cda900b672fb9e5ca785b4c3330eb',1,'Ui_testimonial::retranslateUi()']]]
];
