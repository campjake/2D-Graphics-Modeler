var searchData=
[
  ['brushpatterncombo_0',['brushPatternCombo',['../class_ui___main_window.html#ad8e056512b35efb4b2d9738cafd990f6',1,'Ui_MainWindow']]],
  ['button_5fsave_1',['button_Save',['../class_ui__testimonial.html#a91c769777b8bcef047507ece86e95115',1,'Ui_testimonial']]],
  ['buttonbox_2',['buttonBox',['../class_ui___move_shape.html#a0f6c594ed07303511067f38abcf1e668',1,'Ui_MoveShape']]],
  ['buttongroup_3',['buttonGroup',['../class_ui___main_window.html#a55f96117d4c357547c5ab05918ced798',1,'Ui_MainWindow']]]
];
