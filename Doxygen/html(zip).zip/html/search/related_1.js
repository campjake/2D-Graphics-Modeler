var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_login_dialog.html#af9db4b672c4d3104f5541893e08e1809',1,'LoginDialog']]]
];
