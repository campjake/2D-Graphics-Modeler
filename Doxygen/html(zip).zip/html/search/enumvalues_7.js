var searchData=
[
  ['text_0',['TEXT',['../textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a9a4a47c1606e295076055a9cc4373197',1,'textparser.h']]],
  ['text_1',['Text',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a9dffbf69ffba8bc38bc4e01abf4b1675',1,'shape.h']]]
];
