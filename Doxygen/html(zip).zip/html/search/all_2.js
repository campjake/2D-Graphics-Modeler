var searchData=
[
  ['begin_0',['begin',['../classvector.html#a8de4d56167fefe28a4de236a8056018b',1,'vector::begin()'],['../classvector.html#ab5ea6b3e6ed8c4e6023952789a184e6a',1,'vector::begin() const']]],
  ['brushpatterncombo_1',['brushPatternCombo',['../class_ui___main_window.html#ad8e056512b35efb4b2d9738cafd990f6',1,'Ui_MainWindow']]],
  ['button_5fsave_2',['button_Save',['../class_ui__testimonial.html#a91c769777b8bcef047507ece86e95115',1,'Ui_testimonial']]],
  ['buttonbox_3',['buttonBox',['../class_ui___move_shape.html#a0f6c594ed07303511067f38abcf1e668',1,'Ui_MoveShape']]],
  ['buttongroup_4',['buttonGroup',['../class_ui___main_window.html#a55f96117d4c357547c5ab05918ced798',1,'Ui_MainWindow']]]
];
