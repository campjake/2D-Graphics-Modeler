var searchData=
[
  ['menuaccount_0',['menuAccount',['../class_ui___main_window.html#a09cbac02b9563cc4264290b9702fbac7',1,'Ui_MainWindow']]],
  ['menubar_1',['menubar',['../class_ui___main_window.html#adf43d9a67adaec750aaa956b5e082f09',1,'Ui_MainWindow']]],
  ['menufile_2',['menuFile',['../class_ui___main_window.html#a7ba84cb4cdd6a12dc83bf4e100bd8d80',1,'Ui_MainWindow']]],
  ['menumenu_3',['menuMenu',['../class_ui___main_window.html#a6d7bbbef44e207ee15e5a623171033a2',1,'Ui_MainWindow']]],
  ['menureports_4',['menuReports',['../class_ui___main_window.html#a2916869a2ab725a436f8c959d3139f92',1,'Ui_MainWindow']]],
  ['menushapes_5',['menuShapes',['../class_ui___main_window.html#a684a4c4cf408ecd206fadb7f53537830',1,'Ui_MainWindow']]]
];
