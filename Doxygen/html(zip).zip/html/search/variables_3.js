var searchData=
[
  ['dockwidget_0',['dockWidget',['../class_ui___main_window.html#ac8a083c4b66fb317a9b538409ce412e2',1,'Ui_MainWindow']]],
  ['dockwidgetcontents_1',['dockWidgetContents',['../class_ui___main_window.html#a765ded8236736213d556f6f91941808e',1,'Ui_MainWindow']]]
];
