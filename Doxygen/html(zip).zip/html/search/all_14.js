var searchData=
[
  ['x_0',['x',['../class_move_shape.html#a0ca24fbd5421c01eaf835ce996fdb506',1,'MoveShape']]],
  ['xcoordspin_1',['xCoordSpin',['../class_ui___main_window.html#a936945073e91512e0d2d38c37a1a97f7',1,'Ui_MainWindow']]],
  ['xline_2',['xLine',['../class_ui___move_shape.html#aa2b37a7f2d337e7bfc0de90466fe035d',1,'Ui_MoveShape']]]
];
