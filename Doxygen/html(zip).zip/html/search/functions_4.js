var searchData=
[
  ['ellipse_0',['Ellipse',['../class_ellipse.html#a36011215dd64dc4682382f444339774f',1,'Ellipse::Ellipse(QPaintDevice *device, int anID, ShapeType shapeType, int a, int b)'],['../class_ellipse.html#abce57d1ed427ae1b36b0adb4bbab4bb8',1,'Ellipse::Ellipse(int anID, QPoint qPos, int a, int b)'],['../class_ellipse.html#aa56ed509895685650aacdd823924a7fc',1,'Ellipse::Ellipse(const Ellipse &amp;source)=delete']]],
  ['end_1',['end',['../classvector.html#aee8e1d5328943bb2e1a39cff16747ff9',1,'vector::end()'],['../classvector.html#ab56bde709c6cba222c52cd86de05a4f9',1,'vector::end() const']]],
  ['erase_2',['erase',['../classvector.html#a5275cb7d4081688b4914c2332555fa7a',1,'vector']]]
];
