var searchData=
[
  ['noshape_0',['NoShape',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a9116c0063e85dbe50ecba2653cc5bc42',1,'shape.h']]]
];
