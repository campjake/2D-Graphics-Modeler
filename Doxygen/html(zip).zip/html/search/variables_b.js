var searchData=
[
  ['textedit_0',['textEdit',['../class_ui__testimonial.html#afd3ba9fb052486d36efcb93f6b0faa6a',1,'Ui_testimonial']]],
  ['textsizebox_1',['textSizeBox',['../class_ui___main_window.html#ae0cc5cf26b0b9893dbe7ca0dc063b24e',1,'Ui_MainWindow']]]
];
