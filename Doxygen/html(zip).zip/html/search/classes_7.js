var searchData=
[
  ['testimonial_0',['testimonial',['../classtestimonial.html',1,'testimonial'],['../class_ui_1_1testimonial.html',1,'Ui::testimonial']]],
  ['text_1',['Text',['../class_text.html',1,'']]],
  ['textparser_2',['TextParser',['../class_text_parser.html',1,'']]]
];
