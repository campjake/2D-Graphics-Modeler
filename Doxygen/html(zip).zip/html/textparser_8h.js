var textparser_8h =
[
    [ "TextParser", "class_text_parser.html", "class_text_parser" ],
    [ "ShapeNames", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0", [
      [ "LINE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0ab023460c84f774a219d46ccf4665994c", null ],
      [ "POLYLINE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a50a1f351acd916b6c96bb3ee91ada8f4", null ],
      [ "POLYGON", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0ad5355465780b9a6259ebbc74d47477db", null ],
      [ "RECTANGLE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0ae552ab0a96c0384a6e918e726b7f6102", null ],
      [ "SQUARE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a4233fbf0cafb86abcee94b38d769fc59", null ],
      [ "ELLIPSE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a59c6b7739f239fb18fe5c81692358893", null ],
      [ "CIRCLE", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0aa79c827759ea48f0735386c4b1188911", null ],
      [ "TEXT", "textparser_8h.html#a5223a07d2ae85017a6e62a0d64aadee0a9a4a47c1606e295076055a9cc4373197", null ]
    ] ]
];