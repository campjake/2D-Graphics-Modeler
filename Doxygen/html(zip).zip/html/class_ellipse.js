var class_ellipse =
[
    [ "Ellipse", "class_ellipse.html#a36011215dd64dc4682382f444339774f", null ],
    [ "Ellipse", "class_ellipse.html#abce57d1ed427ae1b36b0adb4bbab4bb8", null ],
    [ "~Ellipse", "class_ellipse.html#a94271a8a2b16101a52491b7e81e28547", null ],
    [ "Ellipse", "class_ellipse.html#aa56ed509895685650aacdd823924a7fc", null ],
    [ "CalcArea", "class_ellipse.html#a26152b96f6cbe13d61fb1cf4f7c21f92", null ],
    [ "CalcPerimeter", "class_ellipse.html#a91867ee66666cfa1dbb99627bcf5979d", null ],
    [ "Draw", "class_ellipse.html#a1940cef8556c9ff52171c025ec01f9f6", null ],
    [ "getHeight", "class_ellipse.html#a19d12b50c8cd9e4b41a9e81deea4ff7e", null ],
    [ "getWidth", "class_ellipse.html#a0a61a195f75d9e6f6be6ce163515151c", null ],
    [ "operator=", "class_ellipse.html#a7447f2d4e447f6b2ebac83b8fe5c9c38", null ],
    [ "setHeight", "class_ellipse.html#ae7ece7450c7500f62b42ec9c32d8a5b1", null ],
    [ "setWidth", "class_ellipse.html#aa4ab57ff33cfa685cdde54a6f963427a", null ]
];