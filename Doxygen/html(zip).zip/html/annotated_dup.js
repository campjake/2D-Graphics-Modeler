var annotated_dup =
[
    [ "Ui", "namespace_ui.html", [
      [ "ContactUs", "class_ui_1_1_contact_us.html", null ],
      [ "LoginDialog", "class_ui_1_1_login_dialog.html", null ],
      [ "MainWindow", "class_ui_1_1_main_window.html", null ],
      [ "MoveShape", "class_ui_1_1_move_shape.html", null ],
      [ "testimonial", "class_ui_1_1testimonial.html", null ]
    ] ],
    [ "Cmp_by_area", "struct_cmp__by__area.html", "struct_cmp__by__area" ],
    [ "Cmp_by_id", "struct_cmp__by__id.html", "struct_cmp__by__id" ],
    [ "Cmp_by_perimeter", "struct_cmp__by__perimeter.html", "struct_cmp__by__perimeter" ],
    [ "ContactUs", "class_contact_us.html", "class_contact_us" ],
    [ "Ellipse", "class_ellipse.html", "class_ellipse" ],
    [ "Line", "class_line.html", "class_line" ],
    [ "LoginDialog", "class_login_dialog.html", "class_login_dialog" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "MoveShape", "class_move_shape.html", "class_move_shape" ],
    [ "Polygon", "class_polygon.html", "class_polygon" ],
    [ "Polyline", "class_polyline.html", "class_polyline" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "RenderArea", "class_render_area.html", "class_render_area" ],
    [ "Shape", "class_shape.html", "class_shape" ],
    [ "testimonial", "classtestimonial.html", "classtestimonial" ],
    [ "Text", "class_text.html", "class_text" ],
    [ "TextParser", "class_text_parser.html", "class_text_parser" ],
    [ "Ui_ContactUs", "class_ui___contact_us.html", "class_ui___contact_us" ],
    [ "Ui_LoginDialog", "class_ui___login_dialog.html", "class_ui___login_dialog" ],
    [ "Ui_MainWindow", "class_ui___main_window.html", "class_ui___main_window" ],
    [ "Ui_MoveShape", "class_ui___move_shape.html", "class_ui___move_shape" ],
    [ "Ui_testimonial", "class_ui__testimonial.html", "class_ui__testimonial" ],
    [ "vector", "classvector.html", "classvector" ]
];