#include "Vector.h"
#include "iostream"
using namespace std;

using table = bool;

int main()
{
	vector<int> v;

	// pushing
	for (int i = 0; i < 100; i++)
	{
		v.push_back(i);
	}

	// erasing 10 from the end
	for (int i = 0; i < 10; i++)
	{
		int* lastElement = v.end() - 1;

		v.erase(lastElement);
	}

	// testing insert method
	int* insertPosition = v.end() - 5;
	int num = -7;
	v.insert(insertPosition, num);

	// erase from middle
	int* erasePosition = v.end() - 3;
	v.erase(erasePosition);

	for (int i = 0; i < v.size(); i++)
	{
		cout << v[i] << " ";
	}

	v.resize(150);

	cout << endl << v.capacity();

	vector<int> v2(v);

	for (int i = 0; i < v.size(); i++)
	{
		cout << v[i] << " ";
	}
	cout << endl;

	vector<int> v3;
	v3 = v;

	for (int i = 0; i < v.size(); i++)
	{
		cout << v[i] << " ";
	}

	return 0;
}